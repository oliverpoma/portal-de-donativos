function solicitarrh(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de ROPA HOMBRE";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=1');
	document.getElementById('enviar').focus();
}
function solicitarrm(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de ROPA MUJER";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=2');
	document.getElementById('enviar').focus();
}
function solicitarrn(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de ROPA NIÑO";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=3');
	document.getElementById('enviar').focus();
}
function solicitaram(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de ACCESORIOS MODA";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=4');
	document.getElementById('enviar').focus();
}
function solicitarit(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de INFORMATICA Y TELEFONIA";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=6');
	document.getElementById('enviar').focus();
}
function solicitarpe(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de PEQUEÑO ELECTRODOMESTICO";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=5');
	document.getElementById('enviar').focus();
}
function solicitarp(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de PAPELERIA";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=7');
	document.getElementById('enviar').focus();
}
function solicitarl(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de LIBRERIA";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=8');
	document.getElementById('enviar').focus();
}
function solicitarra(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de ACCESORIOS ESCOLARES";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=9');
	document.getElementById('enviar').focus();
}
function solicitaro(){
	document.getElementById('formul').setAttribute('class','formulariov');
	document.getElementById('titulo').innerHTML="Donacion de OTROS";
	document.getElementById('form').setAttribute('action','Controlador?op=doSolicitar&idSubcategoria=10');
	document.getElementById('enviar').focus();
}